import React from 'react'

export const List = () => {
  return (
    <div>List</div>
  )
}


export default List