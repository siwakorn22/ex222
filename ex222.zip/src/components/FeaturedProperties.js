import React from 'react'

const FeaturedProperties = () => {
  return (
    <div className='featuredProperties'>
      <div className='featuredPropertiesItem'>
        <img 
            src='https://images.unsplash.com/photo-1600607686527-6fb886090705?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80'
             className='featuredPropertiesImg'
            />
            <div className='featuredPropertiesTitle'>
                <h1>Homes</h1>
                <h2>Madrid</h2>
                <h3>Starting $120</h3>
                <button className='btn'>9.1</button>
            </div>
      </div>

      <div className='featuredPropertiesItem'>
        <img 
            src='https://images.unsplash.com/photo-1512916958891-fcf61b2160df?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80'
             className='featuredPropertiesImg'
            />
            <div className='featuredPropertiesTitle'>
                <h1>Homes</h1>
                <h2>Auslin</h2>
                <h3>Starting $110</h3>
                <button className='btn'>8.9</button>
            </div>
      </div>

      <div className='featuredPropertiesItem'>
        <img 
            src='https://images.unsplash.com/photo-1512918728675-ed5a9ecdebfd?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
             className='featuredPropertiesImg'
            />
            <div className='featuredPropertiesTitle'>
                <h1>Homes</h1>
                <h2>Lispon</h2>
                <h3>Starting $100</h3>
                <button className='btn'>9.0</button>
            </div>
      </div>

      <div className='featuredPropertiesItem'>
        <img 
            src='https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
             className='featuredPropertiesImg'
            />
            <div className='featuredPropertiesTitle'>
                <h1>Homes</h1>
                <h2>Berlin</h2>
                <h3>Starting $150</h3>
                <button className='btn'>8.5</button>
            </div>
      </div>
    </div>
  )
}

export default FeaturedProperties