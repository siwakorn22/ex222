import React from 'react'

const PropertyList = () => {
  return (
    <div className='propertyList'>
      <div className='propertyItem'>
        <img 
            src='https://images.unsplash.com/photo-1566073771259-6a8506099945?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1170&q=80'
             className='propertyImg'
            />
             <div className='propertyTitle'>
                <h1>Hotels</h1>
                <h2>450 hotels</h2>
            </div>    
      </div>

      <div className='propertyItem'>
        <img 
            src='https://images.unsplash.com/photo-1545169734-58a4a6353ccb?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=735&q=80'
             className='propertyImg'
            />
             <div className='propertyTitle'>
                <h1>Appartments</h1>
                <h2>450 apartments</h2>
            </div>    
      </div>

      <div className='propertyItem'>
        <img 
            src='https://images.unsplash.com/photo-1562790351-d273a961e0e9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=765&q=80'
             className='propertyImg'
            />
             <div className='propertyTitle'>
                <h1>Resorts</h1>
                <h2>450 resorts</h2>
            </div>    
      </div>

      <div className='propertyItem'>
        <img 
            src='https://images.unsplash.com/photo-1613490493576-7fde63acd811?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1171&q=80'
             className='propertyImg'
            />
             <div className='propertyTitle'>
                <h1>Villas</h1>
                <h2>450 villas</h2>
            </div>    
      </div>

      <div className='propertyItem'>
        <img 
            src='https://images.unsplash.com/photo-1510798831971-661eb04b3739?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=687&q=80'
             className='propertyImg'
            />
             <div className='propertyTitle'>
                <h1>Cabins</h1>
                <h2>450 cabins</h2>
            </div>    
      </div>
    </div>
  )
}

export default PropertyList